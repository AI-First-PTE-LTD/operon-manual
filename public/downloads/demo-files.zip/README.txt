OPERON DEMO FILES
=================

The files you upload during an Operon demo, in the order you use them. Every file is a
fictional SPECIMEN made for the demo: the companies, people, numbers and addresses are
made up. Do not edit, rename-and-resave, scan or print-and-rescan them: the demo
recognises each file by its exact bytes (see SHA256SUMS).

Files the demo account already has (case papers, portal documents, the bookkeeping
documents) are not in this bundle: they are uploaded for you when the account is opened.

01-incorporation/  Register a new company: Fernreach Botanicals Pte. Ltd.
-------------------------------------------------------------------
Open the incorporation case for Fernreach Botanicals Pte. Ltd.; it waits for the officers' ID documents.
In the people list, upload each file into the matching person and slot, in this order:
  1. Nadia Chua NRIC front (specimen).pdf  ->  Nadia Chua Pei Shan, NRIC (front)
  2. Nadia Chua NRIC back (specimen).pdf  ->  Nadia Chua Pei Shan, NRIC (back)
  3. Haziq Roslan passport (specimen).pdf  ->  Haziq Iskandar bin Roslan, Passport
  4. Haziq Roslan proof of address (specimen).pdf  ->  Haziq Iskandar bin Roslan, Proof of address
Upload the NRIC front before the back.

02-checklist/  Add a director: the client fills the pre-start checklist (Marigold Lane Kitchen Pte. Ltd.)
-------------------------------------------------------------------
Sign in to the client portal as Rachel Lau Pei Qi, open Secretarial, then the checklist
"Change Director". Two answers are already filled in. Fill the rest:
  - New director: add a person. Name Clement Yeo Shao Wen, Singapore citizen / PR,
    e-mail clement.yeo@marigoldlane.example, mobile +65 5201 3368. Then upload:
    1. Clement Yeo NRIC front (specimen).pdf  ->  NRIC (front)
    2. Clement Yeo NRIC back (specimen).pdf  ->  NRIC (back)
  - Board approval (optional): attach
      Marigold Lane board resolution - new director (specimen).pdf
Then submit. Back at the firm, open the case, check what the client sent, tick the
name screening item and confirm.
Upload the NRIC front before the back.

03-change-of-address/  Change the registered office (Marigold Lane Kitchen Pte. Ltd.)
-------------------------------------------------------------------
Open the change of registered address case for Marigold Lane Kitchen Pte. Ltd.
At the first step choose the company's own new address and upload:
  1. Marigold Lane proof of new registered office (specimen).pdf
The demo reads the new address from this letter. The company's BizFile is not in this
bundle yet (see the note below).

04-bookkeeping-C/  One-click fill (company C)
-------------------------------------------------------------------
Pending (task 9.1): which of company C's documents you upload live is not settled yet.
This bundle will carry them once it is.

NOTE
----
The change of address step also asks for the company's BizFile. It is not in this
bundle yet: a BizFile carries dates that follow the demo account, so a fixed copy would
disagree with the account it is uploaded into.
